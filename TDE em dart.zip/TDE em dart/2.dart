import 'dart:io';

void main(){

String? entrada1;
String? entrada2;
entrada1 = stdin.readLineSync(); 
entrada2 = stdin.readLineSync(); 

double entrada1double = double.parse(entrada1!);

double entrada2double = double.parse(entrada2!);

double result = entrada1double + entrada2double;

stdout.write(result); 

}
