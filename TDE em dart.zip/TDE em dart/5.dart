//5) Escreva um programa que inicialize uma variável com o dia de hoje,
// outra com o mês e outra com o ano 
// e imprima a data na tela no formato “dd/mm/aaaa”.


import 'dart:io';

void main(){

int dia = 02;
int mes = 08;
int ano = 2022;

stdout.write("$dia/$mes/$ano"); 

}