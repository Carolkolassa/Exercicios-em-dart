import 'dart:io';

void main(){

String? entrada;
entrada = stdin.readLineSync(); 

double entradadouble = double.parse(entrada!);
double result = entradadouble*2;
stdout.write(result); 

}



