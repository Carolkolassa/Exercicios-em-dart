import 'dart:io';

void main(){

String? entrada;
entrada = stdin.readLineSync(); 

int entradaint = int.parse(entrada!);
int result = entradaint*entradaint;
stdout.write(result); 

}


