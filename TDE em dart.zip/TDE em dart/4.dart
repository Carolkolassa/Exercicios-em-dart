import 'dart:io';

void main(){

String? entrada1;
String? entrada2;
String? entrada3;
entrada1 = stdin.readLineSync(); 
entrada2 = stdin.readLineSync(); 
entrada3 = stdin.readLineSync(); 

double entrada1double = double.parse(entrada1!);

double entrada2double = double.parse(entrada2!);

double entrada3double = double.parse(entrada3!);

double result = (entrada1double + entrada2double + entrada3double) /3;

stdout.write(result); 

}
