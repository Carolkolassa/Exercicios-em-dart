//Escreva um programa que leia a altura
 //e o raio de um cilindro circular e 
 //imprima o volume do mesmo, segundo a fórmula: 
 //V = pi.raio².altura ->obs: Imprima o volume com uma 
//precisão de duas casas decimais.

import 'dart:io';

void main(){

String? raio;
String? altura;

raio = stdin.readLineSync(); 
altura = stdin.readLineSync(); 

double raiodouble = double.parse(raio!);

double alturadouble = double.parse(altura!);

const pi = 3.14;

double formula(){
double result =  pi*(raiodouble*raiodouble)*alturadouble;
return = result.todoubleAsPrecision(2);
}

stdout.write(formula()); 

}